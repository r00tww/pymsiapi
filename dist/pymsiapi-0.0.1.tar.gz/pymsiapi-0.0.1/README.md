# pymsiapi

A library for https://msii.xyz/api.

## Functions

```python
github("r00tww")
steam("Age of History 3")
random_person()
npm_info("msiapi")
```